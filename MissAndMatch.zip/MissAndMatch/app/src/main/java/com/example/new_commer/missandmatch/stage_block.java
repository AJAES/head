package com.example.new_commer.missandmatch;

import android.widget.ImageButton;

/**
 * Created by hskim7341 on 2015-11-02.
 */
public class stage_block {
    public ImageButton b_button;
    public int b_backcolor;
    public int b_shapecolor;
    public int b_shape;
    public int b_position;
    stage_block(){
        this.b_button = null;
        this.b_backcolor = 0;
        this.b_shapecolor = 0;
        this.b_shape = 0;
        this.b_position = 0;
    }
}
